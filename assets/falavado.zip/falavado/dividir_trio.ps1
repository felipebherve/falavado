﻿# Divide uma imagem larga do Gemini com 3 paineis lado a lado em retratos individuais e pins.
# Uso: powershell -File dividir_trio.ps1 -Imagem trio.jpg -Nomes "hipatia,arendt,duchatelet" -Saida pasta [-Tamanho 480]
# Saida: <nome>.jpg (retrato quadrado, peito para cima) e <nome>_pin.jpg (rosto, 128 px) para o pin dos participantes.
param(
  [Parameter(Mandatory=$true)][string]$Imagem,
  [Parameter(Mandatory=$true)][string]$Nomes,
  [Parameter(Mandatory=$true)][string]$Saida,
  [int]$Tamanho = 480,
  [double]$PinY = 0.13
)
Add-Type -AssemblyName System.Drawing
New-Item -ItemType Directory -Force $Saida | Out-Null
$lista = $Nomes -split ','
$im = [System.Drawing.Image]::FromFile($Imagem)
$n = $lista.Count; $pw = $im.Width / $n
$lado = [int]([math]::Min($im.Height, $pw) * 0.96)
$codec = [System.Drawing.Imaging.ImageCodecInfo]::GetImageEncoders() | Where-Object { $_.MimeType -eq "image/jpeg" }
$ep = New-Object System.Drawing.Imaging.EncoderParameters(1)
$ep.Param[0] = New-Object System.Drawing.Imaging.EncoderParameter([System.Drawing.Imaging.Encoder]::Quality, [long]82)
function Recortar($x,$y,$s,$alvo,$arq){
  $b = New-Object System.Drawing.Bitmap $alvo,$alvo
  $g = [System.Drawing.Graphics]::FromImage($b); $g.InterpolationMode = 'HighQualityBicubic'
  $g.DrawImage($im, (New-Object System.Drawing.Rectangle 0,0,$alvo,$alvo), $x, $y, $s, $s, [System.Drawing.GraphicsUnit]::Pixel)
  $g.Dispose(); $b.Save($arq,$codec,$ep); $b.Dispose()
}
for ($i=0; $i -lt $n; $i++) {
  $cx = ($i + 0.5) * $pw
  $x0 = [int]($cx - $lado/2); $y0 = [int](($im.Height - $lado)/2)
  Recortar $x0 $y0 $lado $Tamanho (Join-Path $Saida ($lista[$i] + ".jpg"))
  $sp = [int]($lado * 0.56); $px = [int]($cx - $sp/2); $py = [int]($y0 + $lado*$PinY)
  Recortar $px $py $sp 128 (Join-Path $Saida ($lista[$i] + "_pin.jpg"))
  Write-Host ("ok " + $lista[$i])
}
$im.Dispose()


