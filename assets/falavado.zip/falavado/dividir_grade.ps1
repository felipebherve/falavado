# Corta uma grade (colunas x linhas, ordem de leitura) de avatares em arquivos <nome>_pin.jpg quadrados.
# Uso: powershell -File dividir_grade.ps1 -Imagem folha.jpg -Nomes "a,b,c,d,e,f" -Colunas 4 -Saida pasta [-Tamanho 160] [-Margem 0.02]
param(
  [Parameter(Mandatory=$true)][string]$Imagem,
  [Parameter(Mandatory=$true)][string]$Nomes,
  [Parameter(Mandatory=$true)][int]$Colunas,
  [Parameter(Mandatory=$true)][string]$Saida,
  [int]$Tamanho = 160,
  [double]$Margem = 0.02
)
$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Drawing
$n = $Nomes -split ','
$linhas = [math]::Ceiling($n.Count / $Colunas)
$im = [Drawing.Image]::FromFile((Resolve-Path $Imagem))
$cw = $im.Width / $Colunas; $ch = $im.Height / $linhas
$lado = [math]::Min($cw,$ch) * (1 - 2*$Margem)
New-Item -ItemType Directory -Force $Saida | Out-Null
$enc = [Drawing.Imaging.ImageCodecInfo]::GetImageEncoders() | Where-Object { $_.MimeType -eq 'image/jpeg' }
$ep = New-Object Drawing.Imaging.EncoderParameters 1; $ep.Param[0] = New-Object Drawing.Imaging.EncoderParameter ([Drawing.Imaging.Encoder]::Quality, [long]90)
for ($k=0; $k -lt $n.Count; $k++) {
  $c = $k % $Colunas; $l = [math]::Floor($k / $Colunas)
  $x = $c*$cw + ($cw-$lado)/2; $y = $l*$ch + ($ch-$lado)/2
  $b = New-Object Drawing.Bitmap $Tamanho,$Tamanho
  $g = [Drawing.Graphics]::FromImage($b); $g.InterpolationMode = 'HighQualityBicubic'
  $g.DrawImage($im, (New-Object Drawing.RectangleF 0,0,$Tamanho,$Tamanho), (New-Object Drawing.RectangleF $x,$y,$lado,$lado), [Drawing.GraphicsUnit]::Pixel)
  $g.Dispose(); $b.Save((Join-Path $Saida ($n[$k].Trim() + "_pin.jpg")), $enc, $ep); $b.Dispose()
}
$im.Dispose(); Write-Host "ok: $($n.Count) pins em $Saida"
