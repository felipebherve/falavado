/* Adaptador da mesa para a página do falavado dentro do Claude (gerado pelo dev/montar_pagina_claude.py).
   - A IA é o próprio Claude de quem usa (sample): sem escolha de IAs nem chaves.
   - Sem banco, as rodadas ficam no navegador (o modelo usa o banco local, como no site).
   - Idioma PT, EN ou ES (a ficha D&D já vem em fichas.json); botão para voltar à página inicial; #r-<id> abre uma rodada. */
window.SITE_WEB=true;
window.SITE_CLAUDE=true;
(function(){
  try{ localStorage.setItem('ia_on','claude'); }catch(e){}

  document.addEventListener('DOMContentLoaded',function(){
    /* espanhol: o botão ES traduz a interface (data/es.js) e as falas saem em espanhol */
    if(window.I18N){
      var inst0=I18N.instrucao, fala0=I18N.instrucaoFala;
      I18N.instrucao=function(){ return I18N.lang()==='es'?'\n\nIMPORTANTE: escribe todo lo que se mostrará (titulo, papel y texto de cada fala) en español, manteniendo las ideas reales y la voz de cada pensador. En el campo papel, nombra los papeles especiales en español: "desacuerdo fuerte", "pregunta que duele", "indagación filosófica", "punto de vista de fuera", "respuesta extra". Mantén las claves del JSON exactamente como se piden.':inst0(); };
      I18N.instrucaoFala=function(){ return I18N.lang()==='es'?' Responde en español.':fala0(); };
    }
    /* voltar à página inicial, no topo e no fim */
    var VOLTA={pt:'← Voltar à página principal',en:'← Back to the main page',es:'← Volver a la página principal'};
    function rotulo(){ var l=(document.documentElement.lang||'pt').slice(0,2); return VOLTA[l]||VOLTA.pt; }
    function voltar(cls){ var a=document.createElement('a'); a.href='../index.html'; a.className=cls; a.setAttribute('translate','no'); a.textContent=rotulo(); return a; }
    var v1=voltar('site-voltar'), v2=voltar('site-voltar largo');
    document.body.insertBefore(v1,document.body.firstChild); document.body.appendChild(v2);
    new MutationObserver(function(){ v1.textContent=v2.textContent=rotulo(); }).observe(document.documentElement,{attributes:true,attributeFilter:['lang']});
    /* #r-<id>: abre aquela rodada */
    var h=(location.hash.match(/^#r-([A-Za-z0-9._-]+)$/)||[])[1];
    if(h){ var n=0, t=setInterval(function(){ var b=document.querySelector('[aria-controls="p-'+h+'"]'); if(b){ clearInterval(t); if(b.getAttribute('aria-expanded')!=='true') b.click(); b.scrollIntoView({block:'start'}); } else if(++n>40) clearInterval(t); },150); }
  });
  var st=document.createElement('style');
  /* dentro do Claude não há escolha de IA: a mesa usa o Claude de quem está usando */
  st.textContent='.so-convidado{display:none!important}#contas{display:none!important}'+
    '.site-voltar{display:inline-flex;align-items:center;min-height:44px;margin:max(12px,env(safe-area-inset-top)) 16px 0;font:600 .9rem Lexend,sans-serif;color:#2a1d00;background:linear-gradient(#ffe08a,#e0a92b);border-radius:999px;padding:8px 14px;text-decoration:none}.site-voltar.largo{display:flex;justify-content:center;margin:24px auto 32px;max-width:720px;width:calc(100% - 32px);border-radius:14px;padding:14px}';
  document.head.appendChild(st);
})();
