﻿# Gera as falas da mesa pela API do Gemini TTS e junta tudo numa faixa completa.
# Uso: powershell -File gerar_vozes.ps1 -Entrada falas.json -Saida pasta_saida [-SoNovas]
# falas.json: lista de objetos { "id": "01_marco", "voice": "Bodi", "style": "texto em ingles", "text": "fala em portugues" }
# A chave vem da variavel de usuario GEMINI_API_KEY (nunca mostrar nem gravar a chave).
param(
  [Parameter(Mandatory=$true)][string]$Entrada,
  [Parameter(Mandatory=$true)][string]$Saida,
  [string]$Modelo = "gemini-3.8-flash-tts",
  [int]$PausaSegundos = 22,      # plano gratuito: 3 pedidos por minuto
  [double]$SilencioSeg = 0.9,
  [switch]$SoNovas               # pula falas cujo .wav ja existe
)
$ErrorActionPreference = "Stop"
$k = [Environment]::GetEnvironmentVariable('GEMINI_API_KEY','User')
if (-not $k) { throw "GEMINI_API_KEY nao encontrada na variavel de usuario." }
New-Item -ItemType Directory -Force $Saida | Out-Null
$falas = Get-Content $Entrada -Raw -Encoding UTF8 | ConvertFrom-Json
$uri = "https://generativelanguage.googleapis.com/v1beta/models/$($Modelo):generateContent"

function Get-Pcm([byte[]]$b){
  $i=12
  while($i -lt $b.Length-8){
    $id=[Text.Encoding]::ASCII.GetString($b,$i,4); $sz=[BitConverter]::ToInt32($b,$i+4)
    if($id -eq 'data'){ $n=[Math]::Min($sz,$b.Length-($i+8)); $o=New-Object byte[] $n; [Array]::Copy($b,$i+8,$o,0,$n); return ,$o }
    $i += 8+$sz+($sz%2)
  }
  throw "WAV sem bloco data"
}

$feitas = 0
foreach ($f in $falas) {
  $alvo = Join-Path $Saida ($f.id + ".wav")
  if ($SoNovas -and (Test-Path $alvo)) { Write-Host "pulando $($f.id)"; continue }
  $prompt = "## Style:`n$($f.style)`n`n## Transcript:`n$($f.text)"
  $body = @{
    contents = @(@{ parts = @(@{ text = $prompt }) })
    generationConfig = @{ responseModalities = @("AUDIO"); speechConfig = @{ voiceConfig = @{ prebuiltVoiceConfig = @{ voiceName = $f.voice } } } }
  } | ConvertTo-Json -Depth 8
  $ok = $false
  for ($t=1; $t -le 5 -and -not $ok; $t++) {
    try {
      $r = Invoke-RestMethod -Method Post -Uri $uri -Headers @{ "x-goog-api-key" = $k } -ContentType "application/json; charset=utf-8" -Body ([Text.Encoding]::UTF8.GetBytes($body)) -TimeoutSec 180
      $part = $r.candidates[0].content.parts | Where-Object { $_.inlineData } | Select-Object -First 1
      [IO.File]::WriteAllBytes($alvo, [Convert]::FromBase64String($part.inlineData.data))
      $ok = $true; $feitas++
      Write-Host "ok $($f.id) ($($f.voice))"
    } catch {
      $msg = ""; try { $s = New-Object IO.StreamReader($_.Exception.Response.GetResponseStream()); $msg = $s.ReadToEnd() } catch {}
      if ($msg -match "UNAVAILABLE|INTERNAL") { Write-Host "modelo ocupado (503), tentando de novo"; Start-Sleep -Seconds 20 }
      elseif ($msg -match "RESOURCE_EXHAUSTED" -and $msg -notmatch "PerDay") { Write-Host "limite por minuto, aguardando"; Start-Sleep -Seconds 25 }
      elseif ($msg -match "PerDay") { throw "Limite diario do plano gratuito atingido." }
      else { throw "Erro em $($f.id): " + $_.Exception.Message + " " + $msg.Substring(0,[Math]::Min(200,$msg.Length)) }
    }
  }
  if (-not $ok) { throw "Falhou em $($f.id) apos tentativas." }
  Start-Sleep -Seconds $PausaSegundos
}

# faixa completa, na ordem do arquivo de entrada
$ms = New-Object IO.MemoryStream
$sil = New-Object byte[] ([int](24000*2*$SilencioSeg))
foreach ($f in $falas) {
  $p = Get-Pcm ([IO.File]::ReadAllBytes((Join-Path $Saida ($f.id + ".wav"))))
  $ms.Write($p,0,$p.Length); $ms.Write($sil,0,$sil.Length)
}
$pcm = $ms.ToArray()
$o = New-Object IO.MemoryStream; $w = New-Object IO.BinaryWriter($o)
$w.Write([Text.Encoding]::ASCII.GetBytes("RIFF")); $w.Write([int](36+$pcm.Length)); $w.Write([Text.Encoding]::ASCII.GetBytes("WAVEfmt ")); $w.Write([int]16); $w.Write([int16]1); $w.Write([int16]1); $w.Write([int]24000); $w.Write([int]48000); $w.Write([int16]2); $w.Write([int16]16); $w.Write([Text.Encoding]::ASCII.GetBytes("data")); $w.Write([int]$pcm.Length); $w.Write($pcm); $w.Flush()
[IO.File]::WriteAllBytes((Join-Path $Saida "rodada_completa.wav"), $o.ToArray())
Write-Host ("faixa completa: " + [math]::Round($pcm.Length/48000,1) + " s ; novas geradas: $feitas")
