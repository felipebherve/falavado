﻿# Busca e baixa 3 imagens de referencia de cada pessoa na Wikimedia Commons (dominio publico ou licenca livre com credito).
# Uso: powershell -File buscar_referencias.ps1 -Pessoas "marco=Marcus Aurelius;hipatia=Hypatia" -Pasta refs
# Cria refs\<apelido>\1.jpg, 2.jpg, 3.jpg e refs\<apelido>\creditos.txt (titulo, licenca, autor).
# Respeita o limite da Wikimedia: poucas chamadas, pausas e repeticao com espera em caso de erro.
param(
  [Parameter(Mandatory=$true)][string]$Pessoas,   # "apelido=Nome para busca;apelido2=Outro nome"
  [Parameter(Mandatory=$true)][string]$Pasta,
  [int]$Quantidade = 3,
  [int]$Largura = 640,
  [switch]$SoFaltantes   # pula quem ja tem a quantidade pedida
)
$ErrorActionPreference = "Stop"
$ua = "FalavadoReferencias/1.0 (uso pessoal, poucas chamadas)"
$ok = 'Public domain|^PD|CC0|CC BY|CC-BY|Attribution'
$ruim = 'signature|autograph|grave|tomb|stamp|coin|map|logo|flag|cover|title page|manuscript|monument|plaque|\.pdf'
New-Item -ItemType Directory -Force $Pasta | Out-Null

function Chamar($uri) {
  for ($t=1; $t -le 5; $t++) {
    try { return Invoke-RestMethod -UserAgent $ua -Uri $uri -TimeoutSec 60 }
    catch { Write-Host "  aguardando (tentativa $t): " $_.Exception.Message.Substring(0,[Math]::Min(60,$_.Exception.Message.Length)); Start-Sleep -Seconds (20*$t) }
  }
  throw "Falha repetida na API: $uri"
}

foreach ($p in ($Pessoas -split ';')) {
  if (-not $p.Trim()) { continue }
  $apelido, $nome = $p -split '=', 2
  $dir = Join-Path $Pasta $apelido; New-Item -ItemType Directory -Force $dir | Out-Null
  if ($SoFaltantes -and ((Get-ChildItem $dir -Filter *.jpg -ErrorAction SilentlyContinue).Count -ge $Quantidade)) { Write-Host "${apelido}: ja tem"; continue }
  $busca = Chamar ("https://commons.wikimedia.org/w/api.php?action=query&format=json&list=search&srnamespace=6&srlimit=30&srsearch=" + [uri]::EscapeDataString($nome))
  $titulos = @($busca.query.search | ForEach-Object { $_.title } | Where-Object { $_ -match '\.(jpe?g|png)$' -and $_ -notmatch $ruim } | Select-Object -First 25)
  Start-Sleep -Seconds 2
  # uma unica chamada com todos os titulos candidatos
  $info = Chamar ("https://commons.wikimedia.org/w/api.php?action=query&format=json&prop=imageinfo&iiprop=url|size|extmetadata&iiurlwidth=$Largura&titles=" + [uri]::EscapeDataString(($titulos -join '|')))
  $paginas = $info.query.pages.PSObject.Properties.Value
  $ordem = @{}; for ($k=0; $k -lt $titulos.Count; $k++) { $ordem[$titulos[$k]] = $k }
  $cands = $paginas | Where-Object { $_.imageinfo } | Sort-Object { $ordem[$_.title] }
  $creditos = @(); $n = 0
  foreach ($pg in $cands) {
    if ($n -ge $Quantidade) { break }
    $i = $pg.imageinfo[0]; $m = $i.extmetadata; $lic = $m.LicenseShortName.value
    if ($lic -notmatch $ok -or $i.width -lt 300 -or $i.height -lt 300) { continue }
    try { Start-Sleep -Seconds 2; Invoke-WebRequest -UserAgent $ua -Uri $i.thumburl -OutFile (Join-Path $dir (($n+1).ToString() + ".jpg")) -ErrorAction Stop } catch { Write-Host "  falha ao baixar uma imagem"; continue }
    $n++
    $autor = ($m.Artist.value -replace '<[^>]+>','')
    $creditos += ("$n.jpg | " + $pg.title + " | $lic | $autor")
  }
  [IO.File]::WriteAllLines((Join-Path $dir "creditos.txt"), $creditos)
  Write-Host ("{0}: {1} imagem(ns)" -f $apelido, $n)
  Start-Sleep -Seconds 3
}
