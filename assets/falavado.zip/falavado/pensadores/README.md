# Fichas dos pensadores

Uma ficha por pessoa da mesa, com o mesmo `id` de `modelo_pagina/data/elenco.json`: história, ideias, modo de agir e de pensar, obras, repertório (estudos, cargos, projetos e pontos fortes), ficha de personagem D&D, links de referência, voz e as imagens com as referências usadas para criá-las. Ninguém entra na mesa sem ficha (regra 2 do `CLAUDE.md`).

## Ordem de leitura em toda fala

Sempre que um pensador for selecionado, a fala dele considera, nesta ordem:

1. **A ficha dele** (este diretório): a base de quem ele é e do que pensa.
2. **O que já foi dito antes**: as respostas dos outros pensadores dadas antes dele na rodada, o pensamento do anfitrião e os pensamentos e respostas anteriores. Se um pensamento anterior não tiver nada a ver com o atual, foca só no atual e usa dele no máximo informações sobre a pessoa.
3. **O pensamento atual** que a pessoa mandou.

A resposta leva em conta a ficha D&D, os pontos fortes, os trabalhos que exerceu e as publicações de cada um.

## Como manter

- A ficha D&D fica dentro de cada MD, mas os dados dela estão em `dnd.json`. Para mudar, editar `dnd.json` e rodar `python3 gerar_fichas.py`.
- O mesmo `gerar_fichas.py` refaz `modelo_pagina/data/fichas.json` (o resumo que a página leva ao prompt) e avisa o que ainda falta no padrão de cada pensador.
- Padrão para criar um pensador: MD próprio, 2 a 3 fotos de referência, imagens no Gemini (Ghibli, pins e lovecraftiana com cor natural no rosto, centralizadas do busto para cima), repertório pesquisado e ficha D&D. Pedidos do Gemini em [PROMPTS-GEMINI.md](PROMPTS-GEMINI.md).

## Elenco

| Ficha | Quem é |
|---|---|
| [Marco Aurélio](marco.md) | Imperador romano (161 a 180 d.C.) e filósofo estoico. Escrevia para si mesmo, à noite, nas campanhas militares, para não esquecer como viver. |
| [Carl Jung](jung.md) | Psiquiatra suíço, fundador da psicologia analítica. Sombra, persona, arquétipos, sonhos e individuação. |
| [Espinosa](espinosa.md) | Filósofo racionalista holandês de família judia portuguesa. Deus ou Natureza, os afetos, e a liberdade que nasce de compreender as causas. |
| [Diógenes de Sinope](diogenes.md) | Filósofo cínico grego (século 4 a.C.). Morava num grande jarro em Atenas, zombava das convenções e vivia sem pedir licença. |
| [Nietzsche](nietzsche.md) | Filósofo alemão (1844 a 1900). Morte de Deus, vontade de potência, amor fati, ressentimento e tornar-se quem se é. |
| [Sartre](sartre.md) | Filósofo, romancista e dramaturgo francês (1905 a 1980). Existencialismo: você é o que faz de si, sem álibi. |
| [Hipátia de Alexandria](hipatia.md) | Matemática, astrônoma e filósofa neoplatônica de Alexandria (nascida entre c. 350 e 370, morta em 415). Método, rigor e caráter: medir antes de julgar. |
| [Hannah Arendt](arendt.md) | Filósofa política judia alemã, naturalizada americana (1906 a 1975). Ação, natalidade, pluralidade e a banalidade do mal. |
| [Émilie du Châtelet](duchatelet.md) | Física, matemática e filósofa francesa (1706 a 1749). Traduziu e comentou Newton; defendeu que a felicidade vem do estudo e das paixões compreendidas. |
| [Hipárquia de Maroneia](hiparquia.md) | Filósofa cínica grega (c. 350 a.C.). Trocou a vida de família rica pela rua e pela filosofia. Coragem é ato. |
| [Simone Weil](weil.md) | Filósofa, ativista e mística francesa (1909 a 1943). Atenção, desgraça, força, gravidade e graça, enraizamento. |
| [Sor Juana Inés de la Cruz](sorjuana.md) | Freira, poeta, dramaturga e pensadora do México colonial (1648 a 1695). Defendeu o direito das mulheres de estudar e pensar. |
| [Ben Barres](barres.md) | Neurobiólogo americano da Universidade Stanford (1954 a 2017). Mostrou o papel das células da glia no cérebro e lutou pela igualdade na ciência. |
| [Paul B. Preciado](preciado.md) | Filósofo, escritor e curador espanhol (nascido em 1970). Pensa o corpo como laboratório político e desmonta o que se chama de natural. |
| [Sophie Wilson](wilson.md) | Cientista da computação inglesa (nascida em 1957). Escreveu o BBC BASIC e projetou o conjunto de instruções do processador ARM, presente em bilhões de aparelhos. |
| [Raewyn Connell](connell.md) | Socióloga australiana (nascida em 1944). Criou o conceito de masculinidade hegemônica e defende o conhecimento produzido longe dos centros de poder. |
| [Paulo Freire](freire.md) | Educador e filósofo brasileiro (1921 a 1997). Pedagogia do oprimido: diálogo, leitura do mundo e educação como prática da liberdade. |
| [Michel Foucault](foucault.md) | Filósofo e historiador francês (1926 a 1984). Saber e poder, disciplina e vigilância, biopolítica e cuidado de si. |
| [Karl Marx](marx.md) | Filósofo, economista e jornalista alemão (1818 a 1883). Capitalismo, luta de classes, trabalho alienado e práxis. |
| [Donna Haraway](haraway.md) | Bióloga, filósofa e historiadora da ciência estadunidense (nascida em 1944). Manifesto ciborgue, saberes situados e espécies companheiras. |
| [Triboulet](triboulet.md) | O bufão que serve a mesa. Inspirado no bobo da corte francês Triboulet (c. 1479 a 1536), mas com a persona própria do falavado: garçom, servo e amigo leal, vassalo fiel do rei Herbs. |
