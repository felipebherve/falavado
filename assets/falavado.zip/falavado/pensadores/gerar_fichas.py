"""Mantém as fichas dos pensadores em dia, a partir de dois lugares:
  - pensadores/<id>.md   (ficha completa: história, ideias, jeito, obras, repertório, cuidados...)
  - pensadores/dnd.json  (ficha de personagem D&D de cada um, em dados)

O que faz:
  1. Escreve a ficha D&D dentro do MD de cada pensador, na seção "Ficha de personagem (D&D)",
     entre as marcas <!-- ficha-dnd --> e <!-- /ficha-dnd --> (não editar à mão entre as marcas: editar dnd.json).
  2. Gera modelo_pagina/data/fichas.json (o resumo que a página leva ao prompt), já com o repertório e a ficha D&D.
  3. Confere o padrão de criação de cada pensador e avisa o que falta (seções, ficha D&D, imagens, referências).

Uso: python3 gerar_fichas.py   (rodar sempre que um MD ou o dnd.json mudar)
"""
import json, os, re

AQUI = os.path.dirname(os.path.abspath(__file__))
SKILL = os.path.dirname(AQUI)
IMG = os.path.join(SKILL, 'modelo_pagina', 'img')
D = json.load(open(os.path.join(AQUI, 'dnd.json'), encoding='utf-8'))
EL = {p['id']: p for p in json.load(open(os.path.join(SKILL, 'modelo_pagina', 'data', 'elenco.json'), encoding='utf-8'))['elenco']}
EL.setdefault('triboulet', {'nome': 'Triboulet', 'img': 'triboulet'})
NOMES = {'FOR': 'Força (firmeza no embate)', 'DES': 'Destreza (agilidade retórica)', 'CON': 'Constituição (resistência à dor)',
         'INT': 'Inteligência (rigor e erudição)', 'SAB': 'Sabedoria (percepção)', 'CAR': 'Carisma (presença)'}
INI, FIM = '<!-- ficha-dnd: gerada de dnd.json por gerar_fichas.py; editar lá -->', '<!-- /ficha-dnd -->'
ORDEM = ('Para cada pensador selecionado, ler nesta ordem: 1) a ficha dele (quem é, ideias, jeito, obras, repertório e a ficha D&D); '
         '2) o que já foi dito antes: as falas dos outros pensadores que falaram antes dele nesta rodada, o pensamento do anfitrião '
         'e os pensamentos e respostas das rodadas anteriores, se houver; se um pensamento anterior não tiver nada a ver com o atual, '
         'usar dele no máximo as informações sobre a pessoa; 3) o pensamento atual enviado. A fala nasce da ficha (pontos fortes da ficha D&D, '
         'trabalhos que exerceu e publicações), retoma o que já foi dito e responde ao pensamento de agora.')
SECOES = ['História', 'Ideias centrais', 'Modo de agir', 'Obras e trabalhos', 'Repertório', 'Ficha de personagem (D&D)',
          'Links de referência', 'Voz e jeito de falar', 'Imagens', 'Cuidados nas falas']


def mod(v):
    m = (v - 10) // 2
    return ('+' if m >= 0 else '') + str(m)


def nome(i):
    return EL.get(i, {}).get('nome', i)


def dnd_md(pid, f):
    """A ficha D&D em Markdown, com ### para não quebrar as seções ## do MD."""
    L = ['## Ficha de personagem (D&D)', '', INI, '',
         f'> {f["classe"]} · {f["origem"]} · {f["tendencia"]}', '', f'- **Antecedente:** {f["antecedente"]}', '',
         '### Atributos', '', '| Atributo | Valor | Mod. |', '|---|---|---|']
    L += [f'| {NOMES[k]} | {v} | {mod(v)} |' for k, v in f['atributos'].items()]
    L += ['', f'**Perícias:** {", ".join(f["pericias"])}', '', '**Equipamento:**', ''] + [f'- {e}' for e in f['equipamento']]
    L += ['', '### Habilidades', ''] + [f'- **{h["nome"]}:** {h["efeito"]}' for h in f['habilidades']]
    L += ['', f'**Golpe especial: {f["golpe_especial"]["nome"]}.** {f["golpe_especial"]["efeito"]}', '',
          '### Personalidade', '', f'- **Ideal:** {f["ideal"]}', f'- **Vínculo:** {f["vinculo"]}', f'- **Defeito:** {f["defeito"]}', '',
          '### À mesa', '']
    L += [f'- **Aliado de {nome(a["id"])}:** {a["porque"]}' for a in f['aliados']]
    L += [f'- **Rival de {nome(a["id"])}:** {a["porque"]}' for a in f['rivais']]
    L += [f'- **Na rodada:** {f["na_rodada"]}', f'- **Ponto fraco:** {f["ponto_fraco"]}', '',
          '_Ficha de jogo, inspirada em D&D, para orientar a interação na mesa. Nasce das ideias reais desta ficha; não é biografia nova._',
          '', FIM, '']
    return '\n'.join(L)


def por_dnd(md, pid):
    """Põe (ou troca) a seção D&D no MD, logo antes de "Links de referência"."""
    bloco = dnd_md(pid, D['fichas'][pid])
    md = re.sub(r'^## Ficha de personagem \(D&D\)\n.*?' + re.escape(FIM) + r'\n+', '', md, flags=re.M | re.S)
    alvo = re.search(r'^## Links de referência', md, re.M)
    return md[:alvo.start()] + bloco + '\n' + md[alvo.start():]


def limpo(s):
    return re.sub(r'\*\*?([^*]+)\*\*?', r'\1', s).strip()


def secao(md, titulo):
    m = re.search(r'^## ' + re.escape(titulo) + r'.*?$(.*?)(?=^## |\Z)', md, re.M | re.S)
    return m.group(1).strip() if m else ''


def itens(txt):
    return [limpo(x) for x in re.findall(r'^- (.+)$', txt, re.M)]


def ficha_json(pid, md):
    titulo = re.search(r'^# (.+)$', md, re.M)
    resumo = re.search(r'^> (.+)$', md, re.M)
    ind = re.search(r'^- \*\*Indicada\(o\) por:\*\* (.+?)\.\s', md, re.M)
    cuid = limpo(secao(md, 'Cuidados nas falas').replace('Paráfrase é dita como paráfrase; nada de citações inventadas.', ''))
    hist = '\n'.join(p.strip() for p in secao(md, 'História').split('\n\n') if p.strip())
    rep = secao(md, 'Repertório')
    return {
        'nome': titulo.group(1).strip() if titulo else nome(pid), 'resumo': limpo(resumo.group(1)) if resumo else '',
        'indicado_por': ind.group(1).strip() if ind else None,
        'historia': hist, 'ideias': itens(secao(md, 'Ideias centrais')), 'jeito': itens(secao(md, 'Modo de agir')),
        'obras': itens(secao(md, 'Obras e trabalhos')), 'repertorio': itens(rep),
        'cuidados': cuid, 'dnd': D['fichas'].get(pid),
    }


def conferir(pid, md):
    falta = [s for s in SECOES if not re.search(r'^## ' + re.escape(s), md, re.M)]
    if pid not in D['fichas']:
        falta.append('ficha D&D em dnd.json')
    img = EL.get(pid, {}).get('img', pid)
    for p in (f'{img}.jpg', f'{img}_pin.jpg', f'lc/{img}.jpg', f'lc/{img}_pin.jpg'):
        if not os.path.exists(os.path.join(IMG, p)):
            falta.append('imagem ' + p)
    refs = md.split('**Referências usadas**')[-1] if '**Referências usadas**' in md else secao(md, 'Imagens')
    n = len(re.findall(r'commons\.wikimedia\.org/wiki/File:', refs))
    if pid != 'triboulet' and n < 2:
        falta.append(f'só {n} foto(s) de referência (o padrão pede 2, ideal 3)')
    return falta


if __name__ == '__main__':
    saida, avisos = {}, {}
    ids = list(EL)
    for pid in ids:
        caminho = os.path.join(AQUI, pid + '.md')
        md = open(caminho, encoding='utf-8').read()
        if pid in D['fichas']:
            md = por_dnd(md, pid)
            open(caminho, 'w', encoding='utf-8').write(md)
        saida[pid] = ficha_json(pid, md)
        f = conferir(pid, md)
        if f:
            avisos[pid] = f
    json.dump({'versao': 2, 'ordem': ORDEM, 'fichas': saida},
              open(os.path.join(SKILL, 'modelo_pagina', 'data', 'fichas.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print(len(saida), 'fichas atualizadas (MD com a ficha D&D + data/fichas.json)')
    for pid, f in avisos.items():
        print(f'  falta em {pid}: ' + '; '.join(f))
