# Pedidos para o Gemini (imagens dos pensadores)

Padrão (Herbs, 2026-10-13): de 2 a 3 fotos de referência por pessoa; versão **Studio Ghibli**, **pins** para o site e versão **lovecraftiana com a cor natural de volta nos rostos**; sempre **centralizada, do busto para cima**.

Como usar: abrir uma conversa nova no Gemini (gemini.google.com), anexar as imagens na ordem indicada, colar o pedido e baixar o resultado. Os pins não precisam de pedido próprio: são recortes de 128 px do retrato (`dividir_trio.ps1` ou o Claude recorta quando a imagem estiver salva). Retrato final: quadrado, 480 px, em `modelo_pagina/img/<id>.jpg` (claro) e `modelo_pagina/img/lc/<id>.jpg` (escuro).

Troque `<Nome>`, `<quem é>` e `<cena>` pelos dados da ficha do pensador.

## 1. Versão Studio Ghibli (a partir das fotos)

Anexar as 2 ou 3 fotos de referência.

```
Create an image (not text). I attached reference photos of the same person, <Nome>, <quem é>. Make ONE square portrait of this person in a Studio Ghibli-inspired hand-painted watercolor style. The portrait is centred, from the chest up (bust): head and shoulders fully visible, the whole chin visible, looking at the viewer. Behind the person, a scene that fits their life: <cena>. Keep a faithful, beautiful, favourable and respectful likeness with a natural face. No text, captions, letters or frames.
```

## 2. Versão lovecraftiana (a partir do retrato Ghibli)

Anexar: imagem 1 = o retrato Ghibli novo; imagem 2 = um retrato escuro já aprovado como modelo de estilo (por exemplo `img/lc/barres.jpg`).

```
Create an image (not text). Image 1 is a Studio Ghibli portrait. Image 2 only shows the dark style I want. Redraw image 1 (same person, same pose, same clothes, same framing: centred, from the chest up, whole chin visible, square) in the dark Lovecraftian style of image 2: deep teal and black palette, mist, candlelight and subtle eldritch details in the background (tentacles, a strange moon, old books). Keep the face, neck and hands in their natural human skin colour, warm and lifelike, never grey or green. Beautiful and respectful. No text, captions or frames.
```

## 3. Devolver a cor natural ao rosto (versões escuras antigas)

Anexar: imagem 1 = a versão escura atual (`img/lc/<id>.jpg`); imagem 2 = a versão clara (`img/<id>.jpg`), como referência da cor da pele.

```
Create an image (not text). Image 1 is a dark Lovecraftian portrait and image 2 is the same person in a light Studio Ghibli style. Recreate image 1 as faithfully as possible: same composition, pose, clothes, background, dark teal atmosphere and eldritch details. The only change: give the face, neck and hands their natural human skin colour, taken from image 2, warm, healthy and lifelike, not grey, green or desaturated. Keep the portrait centred, from the chest up, with the whole chin visible, square. No text, captions or frames.
```

## Situação de cada pensador (conferida em 2026-10-13)

| Pensador | Fotos de referência | Ghibli (claro) | Lovecraft (escuro) | O que falta |
|---|---|---|---|---|
| Marco Aurélio, Jung, Espinosa, Diógenes, Nietzsche, Sartre, Hipátia, Arendt, du Châtelet, Hipárquia, Simone Weil, Sor Juana | 3 cada | ok, centralizado do busto para cima | rosto acinzentado/esverdeado | refazer a escura com o pedido 3 |
| Paul B. Preciado | 1 usada; 3 baixadas agora | ok | ok, cor natural | opcional: refazer com as 3 fotos (pedidos 1 e 2) |
| Sophie Wilson | 1 usada; 2 encontradas | ok | ok, cor natural | opcional: refazer com as 2 fotos (pedidos 1 e 2) |
| Ben Barres | 1 (a única foto livre na Wikimedia Commons) | ok | ok, cor natural | não há segunda foto livre; manter |
| Raewyn Connell | 1 (as outras da Commons são a mesma foto impressa numa faixa) | ok | ok, cor natural | não há segunda foto livre; manter |
| Triboulet | 6 (obras antigas) | ok | ok (mesma imagem colorida) | nada |
| Paulo Freire, Michel Foucault, Karl Marx, Donna Haraway (entraram em 2026-10-13) | 3 cada, em `refs\<id>` | ok (Gemini, 2026-10-13) | ok (Gemini, cor natural) | nada |

## Fotos de referência novas (baixadas em 2026-10-13 para `Desktop\projetos\falavado\site_gemini\pensadores\refs\`)

- Preciado: [Paul B. Preciado, with Special Jury Award, Berlinale 2023.jpg](https://commons.wikimedia.org/wiki/File:Paul_B._Preciado,_with_Special_Jury_Award,_Berlinale_2023.jpg) (CC BY-SA 3.0, Elena Ternovaja); [Paul B. Preciado, New York, 2016.jpg](https://commons.wikimedia.org/wiki/File:Paul_B._Preciado,_New_York,_2016.jpg) (CC BY-SA 4.0, Beatriz Preciado); a já usada, de Olaf Kosinsky.
- Sophie Wilson: [Sophie Wilson Presenting.jpg](https://commons.wikimedia.org/wiki/File:Sophie_Wilson_Presenting.jpg) (CC BY 2.0, Jussi Mononen); a já usada, de Chris Monk.

Quando uma delas for usada num retrato novo, o crédito passa para "Referências usadas" na ficha da pessoa.

## Cenas prontas dos quatro novos (para trocar `<Nome>`, `<quem é>` e `<cena>` no pedido 1)

Anexar as fotos de `Desktop\projetos\falavado\site_gemini\pensadores\refs\<id>\`. Feito em 2026-10-13: o Herbs gerou as oito imagens e elas já estão em `img/` e `img/lc/`.

- **Paulo Freire** (`freire`): `<quem é>` = a Brazilian educator and philosopher, old, with a white beard and big glasses; `<cena>` = a circle of adult students on wooden chairs in a simple classroom in the Brazilian Northeast, a blackboard with the word "TIJOLO", warm afternoon light.
- **Michel Foucault** (`foucault`): `<quem é>` = a French philosopher, bald, with thin glasses and a turtleneck sweater; `<cena>` = a Paris library with old archive boxes, and through the window the round silhouette of a panopticon prison tower.
- **Karl Marx** (`marx`): `<quem é>` = a nineteenth-century German philosopher and economist with a large grey beard and a dark frock coat; `<cena>` = the round reading room of the British Museum with tall bookshelves and, through a window, London factory chimneys.
- **Donna Haraway** (`haraway`): `<quem é>` = an American biologist and philosopher, older woman with short grey hair and a warm smile; `<cena>` = a California garden with an Australian Shepherd dog beside her, string figures (cat's cradle) between her fingers and soft circuit-like patterns in the leaves.
