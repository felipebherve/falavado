﻿# Narra uma rodada com as vozes do Windows: Daniel (masculina) e Maria (feminina), em portugues do Brasil.
# Uso: powershell -File narrar.ps1 -Json data\rodadas.json -Rodada r3 -Saida narracao_r3.wav
# Cada fala e precedida pelo nome de quem fala. Mulheres usam Maria, homens usam Daniel; o bufao (Triboulet) usa Daniel mais agudo e rapido.
param(
  [Parameter(Mandatory=$true)][string]$Json,
  [Parameter(Mandatory=$true)][string]$Rodada,
  [Parameter(Mandatory=$true)][string]$Saida
)
$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Runtime.WindowsRuntime
[void][Windows.Media.SpeechSynthesis.SpeechSynthesizer,Windows.Media.SpeechSynthesis,ContentType=WindowsRuntime]
$asTask = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]
function Await($op,$type){ $t=$asTask.MakeGenericMethod($type).Invoke($null,@($op)); [void]$t.Wait(-1); $t.Result }

$mulheres = @('Hipátia de Alexandria','Hannah Arendt','Émilie du Châtelet','Hipárquia de Maroneia','Simone Weil','Sor Juana Inés de la Cruz','Sophie Wilson','Raewyn Connell','Donna Haraway')
# jeito de falar de cada um na narracao (ritmo e tom), para as vozes nao soarem todas iguais
$estilo = @{ 'Marco Aurélio'='rate="0.90" pitch="-1st"'; 'Jung'='rate="0.95" pitch="+0st"'; 'Espinosa'='rate="0.92" pitch="+1st"'; 'Diógenes'='rate="1.06" pitch="+2st"'; 'Nietzsche'='rate="1.08" pitch="-2st"'; 'Sartre'='rate="1.02" pitch="+1st"'; 'Triboulet'='rate="1.12" pitch="+3st"';
 'Hipátia de Alexandria'='rate="0.95" pitch="+0st"'; 'Hannah Arendt'='rate="0.92" pitch="-2st"'; 'Émilie du Châtelet'='rate="1.06" pitch="+2st"'; 'Hipárquia de Maroneia'='rate="1.08" pitch="+1st"'; 'Simone Weil'='rate="0.90" pitch="-1st"'; 'Sor Juana Inés de la Cruz'='rate="0.97" pitch="+1st"';
 'Ben Barres'='rate="0.97" pitch="-1st"'; 'Paul B. Preciado'='rate="1.0" pitch="+0st"'; 'Sophie Wilson'='rate="1.0" pitch="+1st"'; 'Raewyn Connell'='rate="0.95" pitch="+0st"';
 'Paulo Freire'='rate="0.94" pitch="+0st"'; 'Michel Foucault'='rate="1.04" pitch="+1st"'; 'Karl Marx'='rate="0.98" pitch="-2st"'; 'Donna Haraway'='rate="1.02" pitch="+0st"' }
$voces = [Windows.Media.SpeechSynthesis.SpeechSynthesizer]::AllVoices
$maria  = $voces | Where-Object { $_.DisplayName -match 'Maria' -and $_.Language -eq 'pt-BR' } | Select-Object -First 1
$daniel = $voces | Where-Object { $_.DisplayName -match 'Daniel' -and $_.Language -eq 'pt-BR' } | Select-Object -First 1
if (-not $maria -or -not $daniel) { throw "Vozes pt-BR Maria/Daniel nao encontradas." }

$dados = Get-Content $Json -Raw -Encoding UTF8 | ConvertFrom-Json
$r = $dados.rodadas | Where-Object { $_.id -eq $Rodada }
if (-not $r) { throw "Rodada $Rodada nao encontrada." }

function Esc([string]$s){ [Security.SecurityElement]::Escape($s) }
function Sintetizar($voz,$ssml){
  $s = New-Object Windows.Media.SpeechSynthesis.SpeechSynthesizer
  $s.Voice = $voz
  $st = Await ($s.SynthesizeSsmlToStreamAsync($ssml)) ([Windows.Media.SpeechSynthesis.SpeechSynthesisStream])
  $in = [System.IO.WindowsRuntimeStreamExtensions]::AsStreamForRead($st)
  $ms = New-Object IO.MemoryStream; $in.CopyTo($ms); $ms.ToArray()
}
function Ler-Wav([byte[]]$b){
  $rate=[BitConverter]::ToInt32($b,24); $ch=[BitConverter]::ToInt16($b,22); $bits=[BitConverter]::ToInt16($b,34)
  $i=12; while($i -lt $b.Length-8){ $id=[Text.Encoding]::ASCII.GetString($b,$i,4); $sz=[BitConverter]::ToInt32($b,$i+4)
    if($id -eq 'data'){ $n=[Math]::Min($sz,$b.Length-($i+8)); $o=New-Object byte[] $n; [Array]::Copy($b,$i+8,$o,0,$n); return @{ rate=$rate; ch=$ch; bits=$bits; pcm=$o } }
    $i += 8+$sz+($sz%2) }
  throw "WAV sem data"
}

$pcmTotal = New-Object IO.MemoryStream; $taxa = 0; $marcas = @(); $vozesUsadas = @()
foreach ($f in $r.falas) {
  if ($taxa -gt 0) { $marcas += [math]::Round($pcmTotal.Length/($taxa*2),2) } else { $marcas += 0 }
  $ehMulher = $mulheres -contains $f.quem
  $voz = if ($ehMulher) { $maria } else { $daniel }
  if ($estilo.ContainsKey($f.quem)) { $prosodia = $estilo[$f.quem] } elseif ($ehMulher) { $prosodia = 'rate="0.98"' } else { $prosodia = 'rate="0.95"' }
  $ssml = '<speak version="1.0" xmlns="http://www.w3.org/2001/10/synthesis" xml:lang="pt-BR"><prosody rate="0.95">' + (Esc $f.quem) + '.</prosody><break time="350ms"/><prosody ' + $prosodia + '>' + (Esc $f.texto) + '</prosody><break time="700ms"/></speak>'
  $w = Ler-Wav (Sintetizar $voz $ssml)
  if ($w.ch -ne 1 -or $w.bits -ne 16) { throw "Formato inesperado" }
  if ($taxa -eq 0) { $taxa = $w.rate } elseif ($taxa -ne $w.rate) { throw "Taxas diferentes entre vozes: $taxa e $($w.rate)" }
  $pcmTotal.Write($w.pcm,0,$w.pcm.Length)
  $vozesUsadas += $(if ($ehMulher) {"Maria"} else {"Daniel"})
  Write-Host ("ok " + $f.quem + $(if ($ehMulher) {" (Maria)"} else {" (Daniel)"}))
}
# reduz pela metade a taxa (media de 2 amostras) para o arquivo ficar leve
$dst = $pcmTotal.ToArray()
$novaTaxa = $taxa
$o = New-Object IO.MemoryStream; $wr = New-Object IO.BinaryWriter($o)
$wr.Write([Text.Encoding]::ASCII.GetBytes("RIFF")); $wr.Write([int](36+$dst.Length)); $wr.Write([Text.Encoding]::ASCII.GetBytes("WAVEfmt ")); $wr.Write([int]16); $wr.Write([int16]1); $wr.Write([int16]1); $wr.Write([int]$novaTaxa); $wr.Write([int]($novaTaxa*2)); $wr.Write([int16]2); $wr.Write([int16]16); $wr.Write([Text.Encoding]::ASCII.GetBytes("data")); $wr.Write([int]$dst.Length); $wr.Write($dst); $wr.Flush()
[IO.File]::WriteAllBytes($Saida, $o.ToArray())
[IO.File]::WriteAllText(($Saida + ".marcas.json"), ($marcas | ConvertTo-Json -Compress), (New-Object Text.UTF8Encoding($false)))
[IO.File]::WriteAllText(($Saida + ".vozes.json"), ($vozesUsadas | ConvertTo-Json -Compress), (New-Object Text.UTF8Encoding($false)))
Write-Host ("narracao: " + [math]::Round($dst.Length/($novaTaxa*2),1) + " s, " + [math]::Round((Get-Item $Saida).Length/1MB,2) + " MB, taxa $novaTaxa Hz")
